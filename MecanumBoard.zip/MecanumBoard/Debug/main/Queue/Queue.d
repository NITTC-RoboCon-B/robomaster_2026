main/Queue/Queue.o: ../main/Queue/Queue.c ../main/Queue/Queue.h
../main/Queue/Queue.h:
