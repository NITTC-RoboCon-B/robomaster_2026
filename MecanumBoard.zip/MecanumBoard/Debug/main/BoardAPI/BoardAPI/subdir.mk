################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../main/BoardAPI/BoardAPI/can.c \
../main/BoardAPI/BoardAPI/cdc.c \
../main/BoardAPI/BoardAPI/flash.c \
../main/BoardAPI/BoardAPI/gpio.c \
../main/BoardAPI/BoardAPI/irq_nest.c \
../main/BoardAPI/BoardAPI/timer.c 

OBJS += \
./main/BoardAPI/BoardAPI/can.o \
./main/BoardAPI/BoardAPI/cdc.o \
./main/BoardAPI/BoardAPI/flash.o \
./main/BoardAPI/BoardAPI/gpio.o \
./main/BoardAPI/BoardAPI/irq_nest.o \
./main/BoardAPI/BoardAPI/timer.o 

C_DEPS += \
./main/BoardAPI/BoardAPI/can.d \
./main/BoardAPI/BoardAPI/cdc.d \
./main/BoardAPI/BoardAPI/flash.d \
./main/BoardAPI/BoardAPI/gpio.d \
./main/BoardAPI/BoardAPI/irq_nest.d \
./main/BoardAPI/BoardAPI/timer.d 


# Each subdirectory must supply rules for building sources it contributes
main/BoardAPI/BoardAPI/%.o main/BoardAPI/BoardAPI/%.su main/BoardAPI/BoardAPI/%.cyclo: ../main/BoardAPI/BoardAPI/%.c main/BoardAPI/BoardAPI/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main" -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI" -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/PID" -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/Queue" -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/RoboMaster" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-main-2f-BoardAPI-2f-BoardAPI

clean-main-2f-BoardAPI-2f-BoardAPI:
	-$(RM) ./main/BoardAPI/BoardAPI/can.cyclo ./main/BoardAPI/BoardAPI/can.d ./main/BoardAPI/BoardAPI/can.o ./main/BoardAPI/BoardAPI/can.su ./main/BoardAPI/BoardAPI/cdc.cyclo ./main/BoardAPI/BoardAPI/cdc.d ./main/BoardAPI/BoardAPI/cdc.o ./main/BoardAPI/BoardAPI/cdc.su ./main/BoardAPI/BoardAPI/flash.cyclo ./main/BoardAPI/BoardAPI/flash.d ./main/BoardAPI/BoardAPI/flash.o ./main/BoardAPI/BoardAPI/flash.su ./main/BoardAPI/BoardAPI/gpio.cyclo ./main/BoardAPI/BoardAPI/gpio.d ./main/BoardAPI/BoardAPI/gpio.o ./main/BoardAPI/BoardAPI/gpio.su ./main/BoardAPI/BoardAPI/irq_nest.cyclo ./main/BoardAPI/BoardAPI/irq_nest.d ./main/BoardAPI/BoardAPI/irq_nest.o ./main/BoardAPI/BoardAPI/irq_nest.su ./main/BoardAPI/BoardAPI/timer.cyclo ./main/BoardAPI/BoardAPI/timer.d ./main/BoardAPI/BoardAPI/timer.o ./main/BoardAPI/BoardAPI/timer.su

.PHONY: clean-main-2f-BoardAPI-2f-BoardAPI

