################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../main/main_app.c 

OBJS += \
./main/main_app.o 

C_DEPS += \
./main/main_app.d 


# Each subdirectory must supply rules for building sources it contributes
main/%.o main/%.su main/%.cyclo: ../main/%.c main/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main" -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI" -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/PID" -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/Queue" -I"C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/RoboMaster" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-main

clean-main:
	-$(RM) ./main/main_app.cyclo ./main/main_app.d ./main/main_app.o ./main/main_app.su

.PHONY: clean-main

