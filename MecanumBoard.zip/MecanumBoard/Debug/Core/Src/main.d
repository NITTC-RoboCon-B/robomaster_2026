Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/main.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h \
 ../Core/Inc/stm32f4xx_hal_conf.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f446xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_can.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_usb.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd_ex.h \
 ../USB_DEVICE/App/usb_device.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h \
 ../USB_DEVICE/Target/usbd_conf.h \
 C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI.h \
 C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/cdc.h \
 ../USB_DEVICE/App/usbd_cdc_if.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc/usbd_cdc.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ctlreq.h \
 C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/timer.h \
 C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/gpio.h \
 C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/can.h \
 C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/flash.h \
 C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/irq_nest.h
../Core/Inc/main.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h:
../Core/Inc/stm32f4xx_hal_conf.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f446xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_can.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_usb.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd_ex.h:
../USB_DEVICE/App/usb_device.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h:
../USB_DEVICE/Target/usbd_conf.h:
C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI.h:
C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/cdc.h:
../USB_DEVICE/App/usbd_cdc_if.h:
../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc/usbd_cdc.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ctlreq.h:
C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/timer.h:
C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/gpio.h:
C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/can.h:
C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/flash.h:
C:/Users/Owner/STM32CubeIDE/workspace_1.16.0/MecanumBoard/main/BoardAPI/BoardAPI/irq_nest.h:
